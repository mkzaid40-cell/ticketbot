import os
import asyncio
import discord
from discord.ext import commands
from discord import app_commands

TOKEN = os.getenv("TOKEN")

intents = discord.Intents.default()
intents.message_content = True
bot = commands.Bot(command_prefix="!", intents=intents)
ticket_role_id = None

@bot.event
async def on_ready():
    print(f"✅ البوت شغال باسم: {bot.user}")
    try:
        synced = await bot.tree.sync()
        print(f"✅ تم تسجيل {len(synced)} أوامر Slash")
    except Exception as e:
        print(f"❌ خطأ: {e}")

@bot.tree.command(name="setrole", description="تحديد رتبة مستلمي التذاكر")
@app_commands.checks.has_permissions(administrator=True)
async def setrole(interaction: discord.Interaction, role: discord.Role):
    global ticket_role_id
    ticket_role_id = role.id
    await interaction.response.send_message(
        f"✅ تم تحديد رتبة مستلمي التذاكر: {role.mention}", ephemeral=True
    )

class TicketSelect(discord.ui.Select):
    def __init__(self):
        options = [
            discord.SelectOption(label="دعم فني", description="فتح تذكرة للدعم الفني", emoji="🛠️", value="دعم فني"),
            discord.SelectOption(label="شكوى", description="تقديم شكوى", emoji="⚠️", value="شكوى"),
            discord.SelectOption(label="طلب مساعدة", description="طلب المساعدة", emoji="🆘", value="طلب مساعدة"),
            discord.SelectOption(label="طلب إدارة عليا", description="التواصل مع الإدارة العليا", emoji="👑", value="طلب إدارة عليا"),
        ]
        super().__init__(placeholder="🎫 اختر نوع التذكرة", options=options)

    async def callback(self, interaction: discord.Interaction):
        guild = interaction.guild
        user = interaction.user
        category = discord.utils.get(guild.categories, name="Tickets")
        if category is None:
            category = await guild.create_category("Tickets")

        channel_name = f"ticket-{user.id}"
        existing = discord.utils.get(guild.text_channels, name=channel_name)
        if existing:
            await interaction.response.send_message(
                f"❌ عندك تذكرة مفتوحة بالفعل: {existing.mention}", ephemeral=True
            )
            return

        overwrites = {
            guild.default_role: discord.PermissionOverwrite(view_channel=False),
            user: discord.PermissionOverwrite(view_channel=True, send_messages=True, read_message_history=True),
            guild.me: discord.PermissionOverwrite(
                view_channel=True, send_messages=True, read_message_history=True, manage_channels=True
            ),
        }

        if ticket_role_id:
            role = guild.get_role(ticket_role_id)
            if role:
                overwrites[role] = discord.PermissionOverwrite(
                    view_channel=True, send_messages=True, read_message_history=True
                )

        channel = await guild.create_text_channel(
            channel_name, category=category, overwrites=overwrites
        )

        embed = discord.Embed(
            title="🎫 تذكرة جديدة",
            description=(
                f"أهلاً {user.mention}\n\n"
                f"**نوع التذكرة:** {self.values[0]}\n\n"
                "انتظر أحد المسؤولين لمساعدتك."
            ),
            color=discord.Color.blurple(),
        )

        await channel.send(content=user.mention, embed=embed, view=TicketButtons())
        await interaction.response.send_message(
            f"✅ تم فتح تذكرتك: {channel.mention}", ephemeral=True
        )

class TicketPanel(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)
        self.add_item(TicketSelect())

class TicketButtons(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="استلام التذكرة", emoji="📥", style=discord.ButtonStyle.success)
    async def claim(self, interaction: discord.Interaction, button: discord.ui.Button):
        if ticket_role_id is None:
            await interaction.response.send_message(
                "❌ لم يتم تحديد رتبة مستلمي التذاكر.", ephemeral=True
            )
            return
        role = interaction.guild.get_role(ticket_role_id)
        if role not in interaction.user.roles:
            await interaction.response.send_message(
                "❌ ما عندك صلاحية استلام التذاكر.", ephemeral=True
            )
            return
        await interaction.channel.send(
            f"📥 تم استلام التذكرة بواسطة {interaction.user.mention}"
        )
        await interaction.response.send_message("✅ تم استلام التذكرة.", ephemeral=True)

    @discord.ui.button(label="إغلاق التذكرة", emoji="🔒", style=discord.ButtonStyle.danger)
    async def close(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message("🔒 سيتم إغلاق التذكرة خلال 5 ثوانٍ...")
        await asyncio.sleep(5)
        await interaction.channel.delete()

@bot.tree.command(name="setup", description="إنشاء لوحة التذاكر")
@app_commands.checks.has_permissions(administrator=True)
async def setup(interaction: discord.Interaction):
    embed = discord.Embed(
        title="🎫 الدعم الفني",
        description="مرحباً بك في نظام التذاكر.\n\nاختر نوع التذكرة من القائمة بالأسفل:",
        color=discord.Color.blurple(),
    )
    await interaction.channel.send(embed=embed, view=TicketPanel())
    await interaction.response.send_message("✅ تم إنشاء لوحة التذاكر.", ephemeral=True)

@bot.tree.command(name="remind", description="تذكير صاحب التذكرة")
async def remind(interaction: discord.Interaction):
    await interaction.channel.send("🔔 تذكير لصاحب التذكرة: يرجى الرد على التذكرة.")
    await interaction.response.send_message("✅ تم إرسال التذكير.", ephemeral=True)

@bot.tree.command(name="remindstaff", description="تذكير مسؤولي التذاكر")
async def remindstaff(interaction: discord.Interaction):
    if ticket_role_id is None:
        await interaction.response.send_message(
            "❌ لم يتم تحديد رتبة مستلمي التذاكر.", ephemeral=True
        )
        return
    role = interaction.guild.get_role(ticket_role_id)
    await interaction.channel.send(
        f"🔔 تذكير للمسؤولين {role.mention}: توجد تذكرة تحتاج متابعة."
    )
    await interaction.response.send_message("✅ تم تذكير المسؤولين.", ephemeral=True)

if not TOKEN:
    raise RuntimeError("❌ أضف Environment Variable باسم TOKEN.")

bot.run(TOKEN)
